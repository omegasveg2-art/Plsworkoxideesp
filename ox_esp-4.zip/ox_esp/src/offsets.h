// Oxide: Survival Island 1.16.11978 (obfuscated build: re-dump + update after every game patch). Offsets from dump.cs of that version.
#pragma once
#include <cstdint>

struct ClassRef { const char* ns; const char* name; uint64_t typeinfo_rva; };

namespace off {
namespace PlayerManager {            // class Oxide.PlayerManager : NetworkBehaviour
  constexpr ClassRef cls = {"Oxide", "PlayerManager", 0};
  constexpr uint32_t netIdentity = 0x40;          // NetworkBehaviour.<netIdentity>k__BackingField
  constexpr uint32_t fpManager = 0x90;
  constexpr uint32_t vitals = 0xC8;               // PlayerVitals
  constexpr uint32_t s_clientPlayerList = 0x10;   // static List<PlayerManager>
  constexpr uint32_t s_activePlayerList = 0x8;
}
namespace NetworkIdentity { constexpr uint32_t isLocalPlayer = 0x4A; }
namespace FPManager { constexpr ClassRef cls = {"Oxide", "FPManager", 0}; constexpr uint32_t m_WorldCamera = 0x20; }
namespace Vitals {                   // GenericVitals/kAg: Entity (kAH) at 0x68; kAH.Health (reactive float) 0x98, DisplayName 0x88
  constexpr uint32_t Entity = 0x68;
  constexpr uint32_t m_MaxHealth = 0x88;
  constexpr uint32_t E_DisplayName = 0x88;
  constexpr uint32_t E_Health = 0x98;
  constexpr uint32_t E_Velocity = 0xB0;
}
}
